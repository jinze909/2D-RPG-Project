# 2D RPG Project

Unity **2022.3.53f1 国际版**的像素 RPG。当前 `master` 中的
`Assets/Scenes/CombatClearing.unity` 实现三个战术守卫、祭坛 Boss、战斗、封锁与解锁、紧凑 HUD、
胜败重试与持久成长。原玩家原型 `Assets/Scenes/SampleScene.unity` 仍然保留。
工程尚未通过原生试玩，也尚未实现完整世界与剧情。
项目按实际完成的闭环持续扩展，保留原有金发主角。

在 Unity Hub 安装指定版本，克隆后运行 `git lfs pull` 取得真实人物图片，再用
Unity 打开工程及 CombatClearing。WASD/方向键、模拟左摇杆或 D-Pad 移动；
J/空格攻击，K 法力爆发；击败三守卫后 E 唤醒中央祭坛 Boss，击败后 E 激活
北侧信标；附近 E 使用补给。胜败后 R 重试，Esc 暂停，M 静音。
手柄已改为直接向量绑定，但尚未执行真实设备测试。P 仅保留在 SampleScene 的
伤害调试中；新关卡关闭该输入。玩法合同与原生验收见
[Combat Clearing](docs/game/COMBAT_CLEARING.md)。

首轮已修复固定物理更新、死亡/停用后的移动状态、输入资源释放、非法伤害和蓝耗。
第二轮补齐独立运行时属性、重试生命周期与复活触发，并替换了原先循环转向的
临时死亡表现；未新增或替换主角图片。
第三轮候选统一了石墙、苔地、守卫和符文信标的 15 色像素美术，增加蓄力与攻击
生效标记、复用的命中/击杀反馈及音效；临时提示改用边缘位置，暂停或死亡后
不再显示不可执行的交互。PR #2、#3、#4 已普通合并到候选，PR #1 已合入 master。
用户最新要求将原生验收设为可选；它仍未执行，不代表原生试玩通过。
第四轮修复了停用后旧攻击/反馈恢复，以及同一时刻多目标命中受敌人顺序影响的问题；
暂停仍冻结现有动作，冷却、资源与奖励保留。原生物理和试玩仍待验收。
第五轮候选加入本地成长存档：完成信标后保存 30 金币，结算时按 1/2（含数字键盘）
购买生命/法力升级，R 开始下一次挑战时生效；每项最多三级，价格 30/45/60。
保存失败可按 E 重试；未入账就按 R 会丢失本次奖励，已有存档不被自动清空。
详见 [成长与存档合同](docs/game/CLEARING_PROGRESSION.md)。
第六轮为三个守卫接入不同战术：近身方框、锁定方向的长枪、保持距离并标记
当前位置的符文。侧移躲枪、离开标记，趁攻击恢复靠近反击；轮廓与边缘提示区分敌人。
沿用战斗输入、蓝耗、冷却及保存成长，不需要新存档。详见
[敌人战术合同](docs/game/SENTINEL_TACTICS.md)。原生碰撞、美术可读性和难度仍待试玩。
第七轮在实际命中时显示扣除的生命值：普通攻击、爆发和玩家受击使用不同颜色；
致命攻击显示剩余生命值，避免把过量伤害当成真实扣血。数字漂浮淡出，暂停冻结，
击杀后短暂保留，重试或关卡结束时清空。固定对象池复用，沿用已有受击与音效反馈。
详见 [伤害反馈合同](docs/game/DAMAGE_FEEDBACK.md)。原生可读性尚待试玩。
第八轮增加可选探索补给：西侧草药最多恢复 4 HP，东侧符文最多恢复
6 MP；靠近发现后按 E 使用，每处每轮一次，资源已满时保留。符文可补足已有
爆发攻击的蓝耗。道具显示发现/用尽状态和短暂领取脉冲，提示沿用边缘区域；
暂停冻结表现，停用不补货，真正重试才重置。北侧信标和结算存档仍优先使用 E。
详见 [探索补给合同](docs/game/EXPLORATION_SUPPLIES.md)。当前已接入实际玩法，
322 项离线/打包检查和 24 份脚本的 Unity API 引用编译通过（Input System 使用替身）。
[PR #7](https://github.com/jinze909/2D-RPG-Project/pull/7) 已普通合入 master，
实现 CI 已通过；最终源码 CI、完整 ZIP 和下载回验见独立
[第八轮交付回执](https://raw.githubusercontent.com/jinze909/2D-RPG-Project/rpg-deliveries/iteration-008-delivery.json)。原生试玩未执行。
第九轮加入可完成的苔石守护者遭遇：击败三守卫后靠近中央祭坛按 E，
唤醒 108 HP Boss。侧移躲开锁定长枪，离开脚下符文；半血后后续攻击加快，
已有预警保留原时序。Boss 死亡才开北侧封锁，信标仍保存原有 30 金币。
唤醒不回血、不补蓝、不重置补给。新增缓存像素轮廓、实际扣血数字槽、
血量/阶段边缘提示，保留已有输入、伤害反馈、音效与成长。367 项离线/打包检查
及 26 份生产脚本 Unity API 引用编译通过（Input System 替身）；原生验收未执行。
详见 [Boss 遭遇合同](docs/game/BOSS_ENCOUNTER.md) 和
[第九轮接力文档](docs/iterations/2026-10-09-iteration-009/handoff.md)。
[PR #8](https://github.com/jinze909/2D-RPG-Project/pull/8) 已普通合并为 `134e09d`，
实现提交 `b404699` 的 CI 全部 12 步成功；接力校验 100/100。
最终源码、CI、完整 ZIP 和下载回验以独立
[第九轮交付回执](https://raw.githubusercontent.com/jinze909/2D-RPG-Project/rpg-deliveries/iteration-009-delivery.json)
为准，不能从离线结果推断试玩通过。
第十轮修正了 Boss 恢复期躲避指令、补给覆盖半血公告、暂停消耗公告时间，以及
暂停/死亡仍提示反击四处已复现的信息表现。现在按实际状态提示躲避、离开标记或
反击；半血公告与补给操作共存，按游戏时间保持四秒，配有缓存的非颜色反击标记、
阶段脉冲及一次音效。暂停冻结，停用/结束/重试清理；108 HP、伤害、时序和奖励
保持原值。385 项离线/打包检查通过，含 123 项实际方法表现回归，26 份脚本
Unity API 引用编译通过（Input System 替身）；独立代码审查未发现本轮阻塞问题。
检查点 `ac3aa87`、`36567e8` 及审查提交 `7481f5b` 的 CI 均 12/12 通过；
[PR #9](https://github.com/jinze909/2D-RPG-Project/pull/9) 已普通合并为 `a61fada`，
合并父提交与代码树一致性已核实。见 [第十轮接力](docs/iterations/2026-10-09-iteration-010/handoff.md)
及 [合并证据](docs/iterations/2026-10-09-iteration-010/publication.md)。最终源码 CI、
完整 ZIP、哈希和下载回验以发布后的独立
[第十轮交付回执](https://raw.githubusercontent.com/jinze909/2D-RPG-Project/rpg-deliveries/iteration-010-delivery.json)
为准；这份源码记录不预先宣称 ZIP 上传完成。
难度、视觉可读性、动画与音效体验 **尚未进行 Unity 原生验收**；模拟不等于试玩。
注册源已改为 `packages.unity.com`，未升级任何锁定包版本。云端缺少有效 Unity
许可证，尚未完成原生导入、真实碰撞、Animator 视觉或游戏试玩；离线检查不代替它们。

```bash
python3 tools/validate_project.py --root . --output /tmp/rpg-report.json
python3 -m unittest discover -s tests -p 'test_distribution.py'
python3 tools/package_unity_project.py --root . --output /tmp/2D-RPG-Project.zip
```

离线 C# 检查需要 Mono/mcs/csc，可使用系统 `mono-devel` 或本地 Unity 自带工具。
PNG 验证需要 Pillow。脚本从实际工程源码编译，所有程序集写入临时目录。

普通 CI 使用 [RPG Project Validation and ZIP](.github/workflows/rpg-project-validation.yml)，
在代码推送或手动触发后检查工程源码、资源和打包边界，并上传完整工程 ZIP 与报告。
以实际 Actions 运行结果和 Artifact 为交付证据；标准 runner 尚不包含授权 Unity Editor。

第七轮伤害反馈 [PR #6](https://github.com/jinze909/2D-RPG-Project/pull/6) 已普通合并。
实际测试与合并证据见 [交付记录](docs/iterations/2026-10-09-iteration-007/publication.md)
和 [接力文档](docs/iterations/2026-10-09-iteration-007/handoff.md)。最终源码、CI、
完整工程 ZIP 与下载回验记录于独立
[第七轮交付回执](https://raw.githubusercontent.com/jinze909/2D-RPG-Project/rpg-deliveries/iteration-007-delivery.json)。

第六轮战术 PR #5 已普通合并；本轮测试与交付见
[交付记录](docs/iterations/2026-10-09-iteration-006/publication.md)和
[接力文档](docs/iterations/2026-10-09-iteration-006/handoff.md)。最终源码、CI 与
完整工程 ZIP 记录于独立
[第六轮交付回执](https://raw.githubusercontent.com/jinze909/2D-RPG-Project/rpg-deliveries/iteration-006-delivery.json)。

第五轮实际测试与合并记录见
[交付记录](docs/iterations/2026-10-08-iteration-005/publication.md)和
[接力文档](docs/iterations/2026-10-08-iteration-005/handoff.md)。最终源码、
完整 Unity 工程 ZIP、SHA-256 与对应 CI 位于独立
[交付回执](https://raw.githubusercontent.com/jinze909/2D-RPG-Project/rpg-deliveries/iteration-005-delivery.json)。
第四轮及更早的源码、报告与 ZIP 保留。
ZIP 包含 Assets、Packages、ProjectSettings、全部 .meta、文档及八个 Skills；
这是源码工程，尚无原生玩家构建。

8 个许可清晰的 Skills 随源码保存在 [.agents/skills](.agents/skills/README.md)。
每轮先读 [AGENTS.md](AGENTS.md) 和四份根开发记录。实际工程边界与设计约束见
[设计基线](docs/game/DESIGN_BASELINE.md)。
